from setuptools import setup, find_packages

setup(
    name="mypackage",
    version="1.0.1",
    author="Ashish Rekhani",
    description="Segmentation Module",
    packages=['my_package']
)